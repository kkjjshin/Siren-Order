package edu.skku.cs.sirenorder.Model;

public class DatamodelLogin3 {

    private String admin_id;

    public String getAdmin_id() {
        return admin_id;
    }

    public void setAdmin_id(String admin_id) {
        this.admin_id = admin_id;
    }

    public String getCanlogin() {
        return canlogin;
    }

    public void setCanlogin(String canlogin) {
        this.canlogin = canlogin;
    }

    private String canlogin;
}
