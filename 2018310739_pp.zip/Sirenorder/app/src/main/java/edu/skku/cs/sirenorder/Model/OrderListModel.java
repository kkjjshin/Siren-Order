package edu.skku.cs.sirenorder.Model;

public class OrderListModel {
    public String name;
    public String allprice;

    public OrderListModel(String name, String allprice){
        this.name = name;
        this.allprice = allprice;

    }
}
