package edu.skku.cs.sirenorder.Model;

public class MypageModel {
    public String[] nameList;
    public String[] allpriceList;
    public String[] order_now_list;

    public String[] getNameList() {
        return nameList;
    }

    public void setNameList(String[] nameList) {
        this.nameList = nameList;
    }

    public String[] getAllpriceList() {
        return allpriceList;
    }

    public void setAllpriceList(String[] allpriceList) {
        this.allpriceList = allpriceList;
    }

    public String[] getOrder_now_list() {
        return order_now_list;
    }

    public void setOrder_now_list(String[] order_now_list) {
        this.order_now_list = order_now_list;
    }
}
