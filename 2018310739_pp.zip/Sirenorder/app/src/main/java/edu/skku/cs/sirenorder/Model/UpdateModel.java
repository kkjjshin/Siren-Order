package edu.skku.cs.sirenorder.Model;

public class UpdateModel {
    public String name;
    public String order_now;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOrder_now() {
        return order_now;
    }

    public void setOrder_now(String order_now) {
        this.order_now = order_now;
    }
}
