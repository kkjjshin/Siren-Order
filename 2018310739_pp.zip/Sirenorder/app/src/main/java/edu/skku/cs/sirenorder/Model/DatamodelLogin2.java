package edu.skku.cs.sirenorder.Model;

public class DatamodelLogin2 {

    private String user_id;
    private String canlogin;

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getCanlogin() {
        return canlogin;
    }

    public void setCanlogin(String canlogin) {
        this.canlogin = canlogin;
    }
}
