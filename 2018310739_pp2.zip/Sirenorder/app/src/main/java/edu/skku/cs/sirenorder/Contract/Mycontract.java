package edu.skku.cs.sirenorder.Contract;

public interface Mycontract {

    //view
    interface ContractForBasketView{

    }

    interface ContractForMainView{

    }

    interface ContractForMenuView{

    }

    interface ContractForMypageView{

    }

    interface ContractForOrderAcceptView{

    }

    interface ContractForOrderListView{

    }

    //presenter
    interface ContractForBasketPresenter{

    }

    interface ContractForMainPresenter{

    }

    interface ContractForMenuPresenter{

    }

    interface ContractForMypagePresenter{

    }

    interface ContractForOrderAcceptPresenter{

    }

    interface ContractForOrderListPresenter{

    }

    //model
    interface ContractForModel{

    }




}
