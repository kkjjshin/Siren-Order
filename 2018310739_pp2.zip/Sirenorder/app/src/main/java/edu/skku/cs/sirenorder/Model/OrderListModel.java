package edu.skku.cs.sirenorder.Model;

public class OrderListModel {
    public String name;
    public String allprice;
    public String ordernow;

    public OrderListModel(String name, String allprice, String ordernow){
        this.name = name;
        this.allprice = allprice;
        this.ordernow = ordernow;
    }
}
